CREATE TRIGGER ci_produtos_logs
AFTER UPDATE ON ci_produtos
FOR EACH ROW
  BEGIN
INSERT INTO ci_produtos_logs SET id_ci_produtos = NEW.id_ci_produtos, datahora = now(), 
ocorrencia =  CONCAT("Quantidade antiga: ",OLD.qnt_estoque," - Quantidade atual: ",NEW.qnt_estoque);
END;
