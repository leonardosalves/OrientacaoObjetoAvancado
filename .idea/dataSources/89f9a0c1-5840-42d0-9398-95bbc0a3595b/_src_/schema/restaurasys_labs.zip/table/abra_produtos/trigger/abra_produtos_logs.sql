CREATE TRIGGER abra_produtos_logs
AFTER UPDATE ON abra_produtos
FOR EACH ROW
  BEGIN
INSERT INTO abra_produtos_logs SET id_abra_produtos = NEW.id_abra_produtos, datahora = now(), 
ocorrencia =  CONCAT("Quantidade antiga: ",OLD.qnt_estoque," - Quantidade atual: ",NEW.qnt_estoque);
END;
