CREATE TRIGGER finan_lancamentos_conta_update
AFTER UPDATE ON finan_lancamentos
FOR EACH ROW
  BEGIN

INSERT INTO finan_lancamentos_logs
SET id_users = NEW.id_users_lancamento,
data = CURRENT_TIMESTAMP,
total_lancamentos = 1,
modo = 'a'

ON DUPLICATE KEY UPDATE total_lancamentos = total_lancamentos+1; 

END;
