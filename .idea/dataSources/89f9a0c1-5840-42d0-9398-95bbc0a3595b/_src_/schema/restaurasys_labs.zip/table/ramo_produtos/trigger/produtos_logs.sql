CREATE TRIGGER produtos_logs
AFTER UPDATE ON ramo_produtos
FOR EACH ROW
  BEGIN
	INSERT INTO ramo_produtos_logs VALUES 
		('',
		NEW.id_ramo_produtos,
		now(),
		CONCAT('Quantidade antiga: ',OLD.qnt_estoque,' - Quantidade atual: ',NEW.qnt_estoque));
END;
